//
//  HomeView.swift
//  CodeLingual
//
//  Created by Turma01-3 on 06/09/24.
//

import SwiftUI

struct HomeView: View {
    @State var beginner = true
    @State var intermediate = true
    @State var expert = true
    
    var body: some View {
        NavigationStack {
            ZStack {
                LinearGradient(colors: [.background, .background], startPoint: .center, endPoint: .bottom)
                    .ignoresSafeArea()
                
                
                
                ZStack{
                    VStack{
                        HStack{
                            Text("Unidade 1: Conceitos básicos")
                                .padding()
                                .bold()
                            Spacer()
                            Image("Pfp")
                                .resizable()
                                .frame(width: 40, height: 40)
                                .cornerRadius(20)
                            Image("heart")
                                .resizable()
                                .frame(width: 30, height: 30)
                                .padding(.trailing, 10)
                            Text("5")
                                .bold()
                                .padding(.trailing, 10)
                        }
                        .background()
                        .foregroundColor(.orange)
                        .padding(.horizontal, 15)
                        .cornerRadius(10)
                        .backgroundStyle(.blueD)
                        Image("swiftLogo")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 200)
                        
                        
                        Spacer()
                            .frame(height: 20)
                        NavigationLink(destination: ListQuestionsView(beginner2: beginner)){
                            HStack{
                                Image(systemName: "1.square.fill")
                                    .resizable()
                                    .frame(width: 80, height: 80)
                                    .foregroundColor(.purpleD)
                                Text("Sintaxe e estruturas básicas")
                                    .foregroundColor(.purpleD)
                                    .bold()
                            }
                        }
                        NavigationLink(destination: ListQuestionsView(intermediate2: intermediate)){
                            HStack{
                                Text("Tipos de dados e operadores")
                                    .foregroundColor(.yellowD)
                                    .bold()
                                Image(systemName: "2.square.fill")
                                    .resizable()
                                    .frame(width: 80, height: 80)
                                    .foregroundColor(.yellowD)
                            }
                        }
                        NavigationLink(destination: ListQuestionsView(expert2: expert)){
                            HStack{
                                Image(systemName: "3.square.fill")
                                    .resizable()
                                    .frame(width: 80, height: 80)
                                    .foregroundColor(.pinkD)
                                Text("Estruturas de dados e coleções")
                                    .foregroundColor(.pinkD)
                                    .bold()
                            }
                        }
                        Spacer()
                        Text("")
                            .frame(width: 400, height: 10)
                            .background(Color.blueD)
                    }
                }
            }
        }
    }
}

#Preview {
    HomeView()
}
