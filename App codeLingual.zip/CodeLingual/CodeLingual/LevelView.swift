//
//  LevelView.swift
//  CodeLingual
//
//  Created by Turma01-9 on 10/09/24.
//

import SwiftUI

struct LevelView: View {
    
   // let progressView = UIProgressView()
    @State  var downloadAmount = 50.0
    
    var body: some View {
        ZStack{
            Color.background
                .ignoresSafeArea()
            VStack{
                Image("iconeLevel")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 250)
                HStack{
                    Spacer()
                    Image("perfilDefault")
                        .resizable()
                        .scaledToFit()
                        .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/)
                    VStack{
                        Text("Seu nome")
                            .font(.system(size: 30))
                            .bold()
                            .foregroundStyle(.white)
                            .padding(.leading, -65)
                        HStack{
                            VStack{
                                //Barra de progresso
                                ProgressView("Nível 2", value: downloadAmount, total: 100)
                                    .font(.system(size: 22))
                                    .foregroundColor(.draculaBege)
                            }.frame(width: 200, height: 10)
                        }
                    }.padding(.bottom,25)
                    Spacer()
                }.padding(.leading, -85)
                
                Spacer()
                Text("")
                    .frame(width: 400, height: 10)
                    .background(Color.blueD)
            }
        }
    }
}

#Preview {
    LevelView()
}
