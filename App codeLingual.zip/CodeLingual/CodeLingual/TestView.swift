//
//  TestView.swift
//  CodeLingual
//
//  Created by Turma01-9 on 04/09/24.
//

import SwiftUI

struct TestView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    TestView()
}
