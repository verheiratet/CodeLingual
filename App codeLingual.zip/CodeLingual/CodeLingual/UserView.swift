//
//  UserView.swift
//  CodeLingual
//
//  Created by Turma01-3 on 06/09/24.
//

import SwiftUI

struct UserView: View {
    var body: some View {
        NavigationStack{
            ZStack{
                Color.background
                    .ignoresSafeArea()
                VStack{
                    //Ícone de perfil
                    Image("perfilDefault")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 250)
                    //Nome - idade
                    Text("Nome").font(.largeTitle).bold().foregroundStyle(.white).padding(.leading, -180)
                    Text("06/08/1998").font(.title).foregroundStyle(.white).padding(.leading, -180)
                    Spacer()
                    //Ícones - []
                    VStack{
                        HStack{
                            Spacer()
                            VStack{
                                Image("fogoOfensiva")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 50)
                                Text("### dias").font(.system(size: 20)).foregroundStyle(.white)
                                    .frame(alignment: .center)
                            }
                            Spacer()
                            NavigationLink(destination: RankingView()){
                                VStack{
                                    Image("iconeTrofeu")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 50)
                                    Text("Ranking")
                                        .font(.system(size: 20))
                                        .foregroundStyle(.white)
                                }
                            }
                            Spacer()
                            NavigationLink(destination: LevelView()){
                                VStack{
                                    Image("iconeLevel")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 50)
                                    Text("Nível")
                                        .font(.system(size: 20))
                                        .foregroundStyle(.white)
                                }
                            }
                            Spacer()
                        }//.padding(.bottom, 200)
                        /*A solução abaixo não está apropriada, encontrar uma forma de aplicar o modificador .edgesIgnoringSafeArea(.top)*/
                        Spacer()
                    }
                    Text("")
                        .frame(width: 400, height: 10)
                        .background(Color.blueD)
                }
            }
        }.accentColor(.draculaAmarelo)
       
    }
}

#Preview {
    UserView()
}
