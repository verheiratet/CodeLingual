//
//  Model.swift
//  CodeLingual
//
//  Created by Turma01-3 on 09/09/24.
//

import Foundation

struct ContentLevel: Decodable, Hashable {
   // let _id: String
    let level: String
    let questions: [Questions]
    let desc: String
    let resume: String
}

struct Questions: Decodable, Hashable {
    let question: String
    let options: [String]
    let correctAnswer: String
}
