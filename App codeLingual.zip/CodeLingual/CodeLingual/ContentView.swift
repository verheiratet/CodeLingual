//
//  ContentView.swift
//  CodeLingual
//
//  Created by Turma01-9 on 04/09/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            HomeView()
                .tabItem {
                    Label("", systemImage: "house.fill")
                }
            ReviewView()
                .tabItem {
                    Label("", systemImage: "book.closed.fill")
                }
            RankingView()
                .tabItem {
                    Label("", systemImage: "trophy.fill")
                }
            UserView()
                .tabItem {
                    Label("", systemImage: "person.crop.circle")
                }
        }.accentColor(.orangeD)
    }
}

#Preview {
    ContentView()
}
