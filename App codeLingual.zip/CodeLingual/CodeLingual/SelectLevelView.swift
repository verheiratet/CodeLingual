//
//  SelectLevelView.swift
//  CodeLingual
//
//  Created by Turma01-3 on 11/09/24.
//

import SwiftUI

struct SelectLevelView: View {
    @State var beginner = true
    @State var intermediate = true
    @State var expert = true
    
    var body: some View {
        NavigationStack {
            ZStack {
                LinearGradient(colors: [.background, .background], startPoint: .center, endPoint: .bottom)
                    .ignoresSafeArea()
                VStack {
                    Text("Review Concepts")
                        .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                        .foregroundColor(.white)
                    Spacer()
                }
                VStack {
                    NavigationLink(destination: ListQuestionsView(beginner2: beginner)) {
                        
                        Text("Beginner")
                            .foregroundColor(.white)
                            .frame(width: 250, height: 80)
                            .background(Color.blue)
                    }
                    Text("")
                    NavigationLink(destination: ListQuestionsView(intermediate2: intermediate)) {
                        Text("Intermediate")
                            .foregroundColor(.white)
                            .frame(width: 250, height: 80)
                            .background(Color.blue)
                    }
                    Text("")
                    NavigationLink(destination: ListQuestionsView(expert2: expert)) {
                        Text("Expert")
                            .foregroundColor(.white)
                            .frame(width: 250, height: 80)
                            .background(Color.blue)
                    }
                    Text("")
                }
                VStack {
                    Spacer()
                    Text("")
                        .frame(width: 400, height: 10)
                        .background(Color.white)
                }
            }
        }
    }
}

#Preview {
    SelectLevelView()
}
