//
//  ViewModel.swift
//  CodeLingual
//
//  Created by Turma01-3 on 09/09/24.
//

import Foundation

class ViewModel : ObservableObject {
    @Published var chars : [ContentLevel] = []
    
    func fetch() { let task = URLSession.shared.dataTask(with: URL(string: "http://192.168.128.102:1880/busca-questions")!) { data, _, error
        in
        
        do {
            self.chars = try JSONDecoder().decode([ContentLevel].self, from: data!)
        }catch{
            print(error)
        }
    }
        task.resume()
    }
}
