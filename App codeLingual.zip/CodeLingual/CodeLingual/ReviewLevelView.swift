//
//  ReviewLevelView.swift
//  CodeLingual
//
//  Created by Turma01-3 on 09/09/24.
//

import SwiftUI

struct ReviewLevelView: View {
    @StateObject var viewModel = ViewModel()
    @State var intermediate2: Bool = false
    @State var expert2: Bool = false
    @State var beginner2: Bool = false
    
    var body: some View {
        ScrollView {
            VStack {
                ForEach(viewModel.chars, id: \.self) { p in
                    if (beginner2 == true && p.level == "beginner") {
                        VStack {
                            Text(p.resume)
                        }
                    }
                    if (intermediate2 == true && p.level == "intermediate") {
                        VStack {
                            Text(p.resume)
                        }
                    }
                    if (expert2 == true && p.level == "expert") {
                        VStack {
                            Text(p.resume)
                        }
                    }
                }
            }.onAppear() {
                viewModel.fetch()
            }
        }
        
    }
}


#Preview {
    ReviewLevelView()
}
