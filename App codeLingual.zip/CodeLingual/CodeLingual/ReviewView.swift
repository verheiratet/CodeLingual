//
//  ReviewView.swift
//  CodeLingual
//
//  Created by Turma01-3 on 06/09/24.
//

import SwiftUI

struct ReviewView: View {
    @State var beginner = true
    @State var intermediate = true
    @State var expert = true
    
    var body: some View {
        NavigationStack {
            ZStack {
                LinearGradient(colors: [.background, .background], startPoint: .center, endPoint: .bottom)
                    .ignoresSafeArea()
                VStack {
                    Text("Review Concepts")
                        .bold()
                        .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                        .foregroundColor(.white)
                    Spacer()
                }
                VStack {
                    NavigationLink(destination: ReviewLevelView(beginner2: beginner)) {
                        
                        Text("Beginner")
                            .bold()
                            .foregroundColor(.pinkD)
                            .frame(width: 250, height: 80)
                            .background(Color.blue)
                            .cornerRadius(15)
                    }
                    Text("")
                    NavigationLink(destination: ReviewLevelView(intermediate2: intermediate)) {
                        Text("Intermediate")
                            .bold()
                            .foregroundColor(.orangeD)
                            .frame(width: 250, height: 80)
                            .background(Color.blue)
                            .cornerRadius(15)
                    }
                    Text("")
                    NavigationLink(destination: ReviewLevelView(expert2: expert)) {
                        Text("Expert")
                            .bold()
                            .foregroundColor(.greenD)
                            .frame(width: 250, height: 80)
                            .background(Color.blue)
                            .cornerRadius(15)
                    }
                    Text("")
                }
                VStack {
                    Spacer()
                    Text("")
                        .frame(width: 400, height: 10)
                        .background(Color.blueD)
                }
            }
        }
    }
}

#Preview {
    ReviewView()
}
