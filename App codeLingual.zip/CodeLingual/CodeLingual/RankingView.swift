//
//  RankingView.swift
//  CodeLingual
//
//  Created by Turma01-3 on 06/09/24.
//

import SwiftUI

struct RankingView: View {
    var body: some View {
        NavigationStack{
            ZStack{
                
                    LinearGradient(colors: [.background, .background], startPoint: .center, endPoint: .bottom)
                        .ignoresSafeArea()
                
                    VStack{
                        ScrollView{
                        Image("iconeTrofeu")
                            .resizable()
                            .scaledToFit()
                            .frame(height: 150)
                            .padding()
                            .padding()
                        
                        
                        
                        HStack{
                           
                            VStack{
                                Image("vida-de-gato")
                                    .resizable()
                                    //.scaledToFit()
                                    .frame(width: 70,height: 70)
                                    .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                                    
                                
                                Rectangle()
                                    .frame(width: 40,height: 120)
                                    .padding(.bottom,34)
                                    .foregroundColor(.prata)
                                    .cornerRadius(5)
                            }
                            VStack{
                                Image("Krill")
                                    .resizable()
                                   // .scaledToFit()
                                    .frame(width: 70,height: 70)
                                    .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                                
                                Rectangle()
                                    .frame(width: 40,height: 190)
                                    .foregroundColor(.ouro)
                                    .cornerRadius(7)
                            }.padding(.top,-100)
                            VStack{
                                Image("lagartixa")
                                    .resizable()
                                    //.scaledToFit()
                                    .frame(width: 70,height: 70)
                                    .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                                Rectangle()
                                    .frame(width: 40,height: 100)
                                    .foregroundColor(.bronze)
                                    .cornerRadius(7)
                            }  .padding(.bottom,8)
                            
                            
                        }.padding(50)
                            
                        
                        
                        
                        
                        
                        
                        
                       
                    }
                    
                    
                    
                    
                    
                    
                    
                    
                }
                VStack{
                    Spacer()
                    Text("")
                        .frame(width: 400, height: 10)
                        .background(Color.blueD)
                }
            }
        }
    }
}

#Preview {
    RankingView()
}
