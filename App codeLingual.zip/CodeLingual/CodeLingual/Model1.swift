//
//  Model1.swift
//  CodeLingual
//
//  Created by Turma01-3 on 11/09/24.
//

import Foundation
