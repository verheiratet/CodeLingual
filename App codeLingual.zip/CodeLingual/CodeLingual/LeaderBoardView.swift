//
//  LeaderBoardView.swift
//  CodeLingual
//
//  Created by Turma01-9 on 04/09/24.
//

import SwiftUI

struct LeaderBoardView: View {
    var body: some View {
        VStack {
            Text(" ")
        }
    }
}

#Preview {
    LeaderBoardView()
}
