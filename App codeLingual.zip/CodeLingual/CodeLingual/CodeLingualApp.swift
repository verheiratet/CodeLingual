//
//  CodeLingualApp.swift
//  CodeLingual
//
//  Created by Turma01-9 on 04/09/24.
//

import SwiftUI

@main
struct CodeLingualApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
