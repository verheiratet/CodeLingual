//
//  ListQuestionsView.swift
//  CodeLingual
//
//  Created by Turma01-3 on 11/09/24.
//

import SwiftUI

struct ListQuestionsView: View {
    @StateObject var viewModel = ViewModel()
    @State var intermediate2: Bool = false
    @State var expert2: Bool = false
    @State var beginner2: Bool = false
    @State var selectedOption: String = ""
    @State var countCorrects: Int = 0
    
    var body: some View {
        
        ScrollView {
        
                VStack {
                    ForEach(viewModel.chars, id: \.self) { p in
                        if (beginner2 == true && p.level == "beginner") {
                            Text(p.desc)
                            Text(p.level).foregroundColor(.black)
                        }
                        if (intermediate2 == true && p.level == "intermediate") {
                            Text(p.desc)
                            Text(p.level).foregroundColor(.black)
                        }
                        if (expert2 == true && p.level == "expert") {
                            Text(p.desc)
                            Text(p.level).foregroundColor(.black)
                        }
                        ForEach(Array(p.questions.enumerated()), id: \.offset){ index, i in
                            if (beginner2 == true && p.level == "beginner") {
                                VStack(alignment: .leading) {
                                    HStack {
                                        Text("\(index+1)- ")
                                        Text(i.question)
                                    }
                                    ForEach(i.options, id: \.self){ o in
                                        HStack {
                                            Button(action: {
                                                self.selectedOption = o
                                                if(selectedOption == i.correctAnswer){
                                                    countCorrects+=1
                                                }
                                            }) {
                                                HStack{
                                                    Text(o)
                                                        .frame(maxWidth: .infinity, alignment: .leading)
                                                        .padding()
                                                        .background(Color.blue.opacity(0.1))
                                                        .cornerRadius(8)
                                                    
                                                }
                                            }
                                            
                                        }
                                        
                                    }
                                    if(self.selectedOption == i.correctAnswer){
                                        Image(systemName: "checkmark")
                                            .foregroundColor(.green)
                                    }
                                }
                                
                            }
                            if (intermediate2 == true && p.level == "intermediate") {
                                VStack(alignment: .leading) {
                                    HStack {
                                        Text("\(index+1)- ")
                                        Text(i.question)
                                    }
                                    ForEach(i.options, id: \.self){ o in
                                        HStack {
                                            Button(action: {
                                                self.selectedOption = o
                                                if(selectedOption == i.correctAnswer){
                                                    countCorrects+=1
                                                }
                                            }) {
                                                HStack{
                                                    Text(o)
                                                        .frame(maxWidth: .infinity, alignment: .leading)
                                                        .padding()
                                                        .background(Color.blue.opacity(0.1))
                                                        .cornerRadius(8)
                                                    
                                                }
                                            }
                                            
                                        }
                                        
                                    }
                                    if(self.selectedOption == i.correctAnswer){
                                        Image(systemName: "checkmark")
                                            .foregroundColor(.green)
                                    }
                                }
                                
                            }
                            if (expert2 == true && p.level == "expert") {
                                VStack(alignment: .leading) {
                                    HStack {
                                        Text("\(index+1)- ")
                                        Text(i.question)
                                    }
                                    ForEach(i.options, id: \.self){ o in
                                        HStack {
                                            Button(action: {
                                                self.selectedOption = o
                                                if(selectedOption == i.correctAnswer){
                                                    countCorrects+=1
                                                }
                                            }) {
                                                HStack{
                                                    Text(o)
                                                        .frame(maxWidth: .infinity, alignment: .leading)
                                                        .padding()
                                                        .background(Color.blue.opacity(0.1))
                                                        .cornerRadius(8)
                                                    
                                                }
                                            }
                                            
                                        }
                                        
                                    }
                                    if(self.selectedOption == i.correctAnswer){
                                        Image(systemName: "checkmark")
                                            .foregroundColor(.green)
                                    }
                                }
                                
                            }
                        }
                    }
                    Text("\(countCorrects)")
                        .foregroundColor(.black)
                        .font(.system(size: 50))
                }.onAppear() {
                    viewModel.fetch()
                }
            }
            
        }
    }



#Preview {
    ListQuestionsView()
}
