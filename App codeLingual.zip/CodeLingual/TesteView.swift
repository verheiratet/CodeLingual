

import SwiftUI

// Definindo a estrutura principal da visualização
struct TesteView: View {
    // Lista de alternativas disponíveis para seleção
    let alternativas = ["Opção 1", "Opção 2", "Opção 3", "Opção 4"]
    
    // Estado para armazenar a alternativa que o usuário selecionou
    @State private var alternativaSelecionada: String? = nil
    
    var body: some View {
        VStack {
            // Título que indica ao usuário para escolher uma opção
            Text("Escolha uma opção")
                .font(.headline) // Define o estilo de fonte como título
                .padding() // Adiciona espaçamento em torno do texto
            
            // Exibindo uma lista de alternativas usando List
            List(alternativas, id: \.self) { alternativa in
                // Cada alternativa é um botão que pode ser clicado
                Button(action: {
                    // Quando o botão é clicado, define a alternativa selecionada
                    self.alternativaSelecionada = alternativa
                }) {
                    HStack {
                        // Texto da alternativa
                        Text(alternativa)
                            .font(.title2) // Define o estilo de fonte para o texto da alternativa
                        
                        Spacer() // Espaço flexível para empurrar o conteúdo para os lados
                        
                        // Se a alternativa for a selecionada, exibe um ícone de checkmark
                        if self.alternativaSelecionada == alternativa {
                            Image(systemName: "checkmark")
                                .foregroundColor(.blue) // Define a cor do ícone de checkmark
                        }
                    }
                    .padding() // Adiciona espaçamento em torno do conteúdo do botão
                }
                .background(self.alternativaSelecionada == alternativa ? Color.gray.opacity(0.2) : Color.clear) // Altera a cor de fundo se a alternativa estiver selecionada
                .cornerRadius(8) // Adiciona bordas arredondadas ao botão
            }
            .listStyle(InsetGroupedListStyle()) // Define o estilo da lista para uma aparência agrupada e com margens
    
            // Exibe a alternativa selecionada, se houver uma
            if let selecionada = alternativaSelecionada {
                Text("Você selecionou: \(selecionada)")
                    .font(.title) // Define o estilo de fonte como título
                    .padding() // Adiciona espaçamento em torno do texto
            }
        }
        .padding() // Adiciona espaçamento em torno do VStack
    }
}

// Estrutura para visualização da prévia do ContentView
struct TesteView_Previews: PreviewProvider {
    static var previews: some View {
        TesteView() // Exibe a ContentView na prévia
    }
}
